<?php

namespace App\Models\Cadastro;

use Illuminate\Database\Eloquent\Model;

class SubEspecieDAO extends Model
{
    protected $table = 'sub_especie';
    protected $fillable = ['sub_especie'];
	public $timestamps = false;
	
	//Adicionar sub especie
	public function addSubEspecie($dados){
	 return SubEspecieDAO::create($dados);
	}
	
	
	
	//buscar todas sub especie
	public function getAllSubEspecie(){
	 return SubEspecieDAO::all();
	}
	
	
	//p
	
}
