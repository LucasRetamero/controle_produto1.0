<?php

namespace App\Models\Cadastro;

use Illuminate\Database\Eloquent\Model;

class LocalizacaoDAO extends Model
{
    //
}
