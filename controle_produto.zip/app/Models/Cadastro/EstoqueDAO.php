<?php

namespace App\Models\Cadastro;

use Illuminate\Database\Eloquent\Model;

class EstoqueDAO extends Model
{
    //
}
