<?php

namespace App\Models\Cadastro;

use Illuminate\Database\Eloquent\Model;

class ProdutosDAO extends Model
{
    //
}
