<?php

namespace App\Models\Cadastro;

use Illuminate\Database\Eloquent\Model;

class EnderecoDAO extends Model
{
    //
}
