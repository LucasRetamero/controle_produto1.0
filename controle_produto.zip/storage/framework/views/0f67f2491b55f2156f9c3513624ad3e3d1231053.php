

<?php $__env->startSection('title','Controle de produto - Home'); ?>


<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('dashboard.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\Projects\Controle de Produto\controle_produto\resources\views/dashboard/index.blade.php ENDPATH**/ ?>