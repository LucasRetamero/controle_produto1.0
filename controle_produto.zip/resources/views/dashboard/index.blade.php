@extends('dashboard.default')

@section('title','Controle de produto - Home')


@section('content')
 @include('dashboard.home')
@endsection